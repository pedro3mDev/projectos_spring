package grupo3mtech.ao.pagamento;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @GetMapping("/info")
    public String getPaymentInfo() {
        return "Informações de pagamento acessadas com sucesso!";
    }
}

