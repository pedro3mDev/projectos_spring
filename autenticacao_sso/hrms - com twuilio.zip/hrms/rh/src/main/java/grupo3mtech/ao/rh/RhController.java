package grupo3mtech.ao.rh;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/rh")
public class RhController {

    @GetMapping("/info")
    public String getRhInfo() {
        return "Informações de RH acessadas com sucesso!";
    }
}

