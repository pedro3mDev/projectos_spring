package grupo3mtech.ao.autenticacao.service;
import  grupo3mtech.ao.autenticacao.constants.Constantes;
import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class SmsService {
    public void enviarMensagem(String numeroDestino, String messagem) {
        try {
            Twilio.init(Constantes.TWILIO_ID, Constantes.TWILIO_TOKEN);
            PhoneNumber para = new PhoneNumber(numeroDestino);
            Message.creator(para, new PhoneNumber( Constantes.TWILIO_NUMERO_ORIGEN), messagem).create();
        } catch (ApiException e) {
            System.err.println("Erro de Autenticação Twilio: " + e.getMessage());

        }
    }

    /*
    private Map<String, String> verificationCodes = new HashMap<>();
    private Random random = new Random();
    private String codigoGerado;
    @Autowired
    private SmsService smsService;

    //Função para Gerar Código de Verificação
    public String gerarCodigoVerificacao(String nomeUsuario) {
        codigoGerado = String.format("%06d", random.nextInt(999999));
        verificationCodes.put(nomeUsuario, codigoGerado);
        return codigoGerado;
    }

    //Função para Validar Código de Verificação
    public boolean validaCodigoVerificacao2(String codigo) {
        if (codigoGerado.equals(codigo) ) {
            System.out.println("Código verificado com sucesso!");
        } else
            System.out.println("Código inválido!");
        return false;
    }

    //Função para Validar Código de Verificação
    public boolean validaCodigoVerificacao(String codigo) {
        if (codigoGerado.equals(codigo) ) {
            System.out.println("Código verificado com sucesso!");
            enviarMensagem(Constantes.TWILIO_NUMERO_DESTINO, "Seu código de verificação é: " + codigo);
        } else
            System.out.println("Código inválido!");
        return false;
    }


     */


}
