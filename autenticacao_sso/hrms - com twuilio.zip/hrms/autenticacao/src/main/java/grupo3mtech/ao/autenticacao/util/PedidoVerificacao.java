package grupo3mtech.ao.autenticacao.util;
import lombok.Data;
@Data
public class PedidoVerificacao {
    private String nomeUsuario;
    private String codigo;

}
