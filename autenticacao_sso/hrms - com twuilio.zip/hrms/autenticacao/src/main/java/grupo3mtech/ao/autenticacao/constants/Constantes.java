package grupo3mtech.ao.autenticacao.constants;

public class Constantes {
    public static final String CHAVESECRETA = "secret_key";
    public static final String CONTA_NOME_USUARIO = "admin";
    public static final String CONTA_SENHA = "1234";
    public static final String TWILIO_ID = "AC5909faeba78334671da1115510550df6";
    public static final String TWILIO_TOKEN = "a0c03ef9c15669371cc27cdbb3149ac6";
    public static final String TWILIO_NUMERO_ORIGEN = "+16614491026";
    public static final String TWILIO_NUMERO_DESTINO = "+244931537786";

}
