package grupo3mtech.ao.autenticacao.util;
import lombok.Data;

//@RequestBody
@Data
public class RequisicaoAutenticacao {
    private String nomeUsuario;
    private String senhaUsuario;

}
