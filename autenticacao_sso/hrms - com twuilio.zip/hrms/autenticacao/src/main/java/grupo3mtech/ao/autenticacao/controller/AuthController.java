package grupo3mtech.ao.autenticacao.controller;
import grupo3mtech.ao.autenticacao.constants.Constantes;
import grupo3mtech.ao.autenticacao.repository.UsuarioRepository;
import grupo3mtech.ao.autenticacao.service.VerificaSmsService;
import grupo3mtech.ao.autenticacao.util.RequisicaoAutenticacao;
import grupo3mtech.ao.autenticacao.util.RespostaAutenticacao;
import grupo3mtech.ao.autenticacao.util.PedidoVerificacao;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.Date;
import grupo3mtech.ao.autenticacao.util.JwtUtil;

@RestController
public class AuthController {
    private JwtUtil jwtUtil;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private VerificaSmsService verificaSmsService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody RequisicaoAutenticacao requisicaoAutenticacao) throws Exception {
        if (requisicaoAutenticacao.getNomeUsuario().equals(Constantes.CONTA_NOME_USUARIO)) {
            if (requisicaoAutenticacao.getSenhaUsuario().equals(Constantes.CONTA_SENHA)) {
                String codigo = verificaSmsService.gerarCodigoVerificacao(requisicaoAutenticacao.getNomeUsuario());
                verificaSmsService.validaCodigoVerificacao(codigo);
                return ResponseEntity.status(HttpStatus.ACCEPTED).body(new RespostaAutenticacao("Codigo de Vericação Enviado para o seu Numero!"));
            }
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new RespostaAutenticacao("Senha inválida!"));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new RespostaAutenticacao("Usuário Invalido!"));
    }

    @PostMapping("/verifica")
    public ResponseEntity<?> verify(@RequestBody PedidoVerificacao pedidoVerificacao) throws Exception {
        String jwt = Jwts.builder()
                .setSubject(pedidoVerificacao.getNomeUsuario())
                .setExpiration(new Date(System.currentTimeMillis() + 30 * 60 * 1000))
                .signWith(SignatureAlgorithm.HS256, Constantes.CHAVESECRETA)
                .compact();
        return ResponseEntity.ok(new RespostaAutenticacao(jwt));
    }

    /*
    //Login a partir da Base de Dados
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest authRequest) {
        Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
        logger.info("Tentando fazer login para o usuário: " + authRequest.getUsername());

        Optional<User> userOptional = userRepository.findByUsername(authRequest.getUsername());
        if (userOptional.isPresent()) {
            logger.info("Usuário encontrado: " + authRequest.getUsername());
            User user = userOptional.get();
            if (user.getPassword().equals(authRequest.getPassword())) {
                logger.info("Senha válida para o usuário: " + authRequest.getUsername());
                String code = verificationService.generateVerificationCode(authRequest.getUsername());
                verificationService.validateVerificationCode(code);
                return ResponseEntity.ok(new AuthResponse("Código de verificação enviado para o seu número!"));
            } else {
                logger.warning("Senha inválida para o usuário: " + authRequest.getUsername());
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new AuthResponse("Senha inválida!"));
            }
        } else {
            logger.warning("Usuário não encontrado: " + authRequest.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new AuthResponse("Usuário não encontrado!"));
        }
    }
    */


}


