package grupo3mtech.ao.autenticacao.service;
import grupo3mtech.ao.autenticacao.service.SmsService;
import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import grupo3mtech.ao.autenticacao.constants.Constantes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class VerificaSmsService {
    private Map<String, String> verificationCodes = new HashMap<>();
    private Random random = new Random();
    private String codigoGerado;
    @Autowired
    private SmsService smsService;

    //Função para Gerar Código de Verificação
    public String gerarCodigoVerificacao(String nomeUsuario) {
        codigoGerado = String.format("%06d", random.nextInt(999999));
        verificationCodes.put(nomeUsuario, codigoGerado);
        return codigoGerado;
    }

    //Função para Validar Código de Verificação
    public boolean validaCodigoVerificacao2(String codigo) {
        if (codigoGerado.equals(codigo) ) {
            System.out.println("Código verificado com sucesso!");
        } else
            System.out.println("Código inválido!");
        return false;
    }

    //Função para Validar Código de Verificação
    public boolean validaCodigoVerificacao(String codigo) {
        if (codigoGerado.equals(codigo) ) {
            System.out.println("Código verificado com sucesso!");
            smsService.enviarMensagem(Constantes.TWILIO_NUMERO_DESTINO, "Seu código de verificação é: " + codigo);
        } else
            System.out.println("Código inválido!");
        return false;
    }



}
