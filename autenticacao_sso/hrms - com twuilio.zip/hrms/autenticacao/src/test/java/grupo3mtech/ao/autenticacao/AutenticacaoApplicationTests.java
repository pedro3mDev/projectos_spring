package grupo3mtech.ao.autenticacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

class AutenticacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
